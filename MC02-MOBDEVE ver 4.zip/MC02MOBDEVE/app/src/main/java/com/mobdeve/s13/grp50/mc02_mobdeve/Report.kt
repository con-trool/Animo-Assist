package com.mobdeve.s13.grp50.mc02_mobdeve

data class Report(
    val title: String,
    val status: String,
    val date: String
)
